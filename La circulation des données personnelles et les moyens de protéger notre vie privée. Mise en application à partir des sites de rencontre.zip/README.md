# Readme - fonio static website

This story was successfully exported from the free software Fonio.

Please be advised that the website you have downloaded won't be functionnal if you directly open HTML files on your computer: you'll have to setup a local server or to upload the website online to see it work.

You can read this tutorial for publishing a website: https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/Publishing_your_website

Here are suggestions for publishing your website with a free and beginner-friendly service : 

**Github Pages** - https://github.com - tutorial here : https://developer.mozilla.org/en-US/docs/Learn/Getting_started_with_the_web/Publishing_your_website

**Netlify drop** - https://app.netlify.com/drop